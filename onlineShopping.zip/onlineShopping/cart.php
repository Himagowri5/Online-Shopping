<?php
session_start();
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shoping";
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete an item
if (isset($_GET['delete'])) {
    $name = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM cart WHERE product_name = '$name'");
}

// Add item to cart
if (isset($_POST['product_name'])) {
    $pname = $_POST['product_name'];
    $result = $conn->query("SELECT * FROM fashion WHERE product_name = '$pname'");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Check if product already in cart
        $check = $conn->query("SELECT * FROM cart WHERE product_name = '$pname'");
        if ($check->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO cart (product_name, product_price, product_type, product_size, image) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sdsss", $row['product_name'], $row['product_price'], $row['product_type'], $row['product_size'], $row['image']);
            $stmt->execute();
        }
    }
}

// Fetch cart items
$cart_items = [];
$total = 0;
$result = $conn->query("SELECT * FROM cart");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $cart_items[] = $row;
        $total += $row['product_price'];
    }
}

echo "
<style>
    body { font-family: Arial, sans-serif; padding: 20px; background-color: #f7f9fc; }
    table { border-collapse: collapse; width: 80%; margin: auto; }
    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
    th { background-color: #007BFF; color: white; }
    td img { width: 80px; height: 80px; }
    .order-button {
        display: block;
        width: 200px;
        margin: 20px auto;
        padding: 10px;
        background-color: #28a745;
        color: white;
        border: none;
        font-size: 18px;
        cursor: pointer;
        border-radius: 5px;
        text-decoration: none;
        text-align: center;
    }
    .order-button:hover {
        background-color: #218838;
    }
    .delete-button {
        color: red;
        font-weight: bold;
        text-decoration: none;
    }
</style>
";

echo "<h2 style='text-align:center;'>Your Cart</h2>";

if (count($cart_items) > 0) {
    echo "<table>";
    echo "<tr>
            <th>Name</th>
            <th>Price</th>
            <th>Type</th>
            <th>Size</th>
            <th>Image</th>
            <th>Action</th>
          </tr>";
    foreach ($cart_items as $item) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['product_name']) . "</td>";
        echo "<td>₹" . htmlspecialchars($item['product_price']) . "</td>";
        echo "<td>" . htmlspecialchars($item['product_type']) . "</td>";
        echo "<td>" . htmlspecialchars($item['product_size']) . "</td>";
        echo "<td><img src='" . htmlspecialchars($item['image']) . "'></td>";
        echo "<td><a class='delete-button' href='cart.php?delete=" . urlencode($item['product_name']) . "'>Delete</a></td>";
        echo "</tr>";
    }
    echo "<tr><td colspan='6' style='text-align:right; font-weight:bold;'>Total: ₹" . $total . "</td></tr>";
    echo "</table>";
    echo "<a href='order1.html' class='order-button'>Place Order</a>";
} else {
    echo "<p style='text-align:center;'>Your cart is empty.</p>";
}

$conn->close();
?>


