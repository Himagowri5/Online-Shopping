<?php

if(isset($_POST['update']))
{
	$host = "localhost";
	$dbusername = "root";
	$dbpassword = "";
    $dbname = "shoping";
    $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
    
    $Order_id = $_POST['Order_id'];
    $Product_id = $_POST['Product_id'];
    $Product_name = $_POST['Product_name'];
    $date_of_order = $_POST['date_of_order'];
    $Customer_name = $_POST['Customer_name'];
    $Product_type = $_POST['Product_type'];
    $sql = "UPDATE order_table SET Product_id= '$Product_id' ,Product_name= '$Product_name' ,date_of_order = '$date_of_order', Customer_name = '$Customer_name' , Product_name= '$Product_name'   WHERE Order_id= '".$Order_id."' ";

    if($conn->query($sql))
    {
    	echo "<p><font color=white>Data updated</font></p>";

    }
    else{
    	echo 'Data not updated';
    }
    $conn->close();

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>update data</title>
    <style>
       body {
    background-color : #484848;
    margin: 0;
    padding: 0;
}
h1 {
    color : white;
    text-align : center;
    font-family: "SIMPSON";
}
form {
    width: 300px;
    margin: 0 auto;
    color: orange;
    font-size: 30px;
     text-align:center;
}
    </style>

</head>
<body background='http://localhost/onlineShopping/requiredphotos/bg2.jpg'>
    <h1>Update data</h1>
	<form  action="oupdate.php" method="post">
		Id to update: <input type="int" name="Order_id"  required><br><br>
		
          New Product Name: <input type="text" name="Product_name" required><br><br>
       New date of order: <input type="date" name="date_of_order" required><br><br>
       New Customer Nme: <input type="text" name="Customer_name" required><br><br>
        
        <div align="center">
		<input type="submit" name="update" value="Update data">
    </div>
	</form>
    <br>

</body>
</html>