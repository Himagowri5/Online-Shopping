<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
table {
    font-family: "Lato", "cursive"; 
    width: 100%;
}       

table.one {
    margin-bottom: 3em; 
    border-collapse: collapse;
}

td {
    text-align: center;     
    width: 10em;                    
    padding: 1em;
}

th {
    text-align: center;                 
    padding: 1em;
    background-color: black;
    color: white;
}

tr {
    height: 1em;
}

table tr:nth-child(even) {
    background-color: #eee;
}

table tr:nth-child(odd) {
    background-color: #fff;
}
</style>
</head>
<body>
<table>
<tr>
<th>Product Name</th>
<th>Product Price</th>
<th>Image</th>
<th>Customer Name</th>
<th>City</th>
<th>Address</th>
<th>Pincode</th>
<th>Phone No.</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "shoping");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// JOIN order_items with orders using order_id
$sql = "SELECT 
            order_items.product_name,
            order_items.product_price,
            order_items.image,
            orders.customer_name,
            orders.city,
            orders.addres,
            orders.pincode,
            orders.phone_no
        FROM order_items
        JOIN orders ON order_items.order_id = orders.order_id";  // replace `id` with your actual primary key in orders table

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["product_name"] . "</td>
                <td>" . $row["product_price"]. "</td>
                <td><img src='" . $row["image"] . "' width='100'></td>
                <td>" . $row["customer_name"] . "</td>
                <td>" . $row["city"].  "</td>
                <td>" . $row["addres"] . "</td>
                <td>" . $row["pincode"] . "</td>
                <td>". $row["phone_no"] . "</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='8'>0 results</td></tr>";
}

$conn->close();
?>
</table>
</body>
</html>
