<?php

if(isset($_POST['update']))
{
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "shoping";
    $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

    
    $Product_name = $_POST['Product_name'];
    $Product_price = $_POST['Product_price'];
    $Product_type = $_POST['Product_type'];
    $Product_quantity = $_POST['Product_quantity'];
  

    $sql = "UPDATE fashion SET  product_name= '$Product_name' ,product_price= '$Product_price' ,product_type = '$Product_type' ,product_size = '$Product_size'  WHERE product_name= '".$Product_name."' ";

    if($conn->query($sql))
    {
        echo "<p><font color=red>Data updated</font></p>";

    }
    else{
        echo 'Data not updated';
    }
    $conn->close();

}
?>
<!DOCTYPE html>
<html>
<head>
    <title>update data</title>
    <style>
       body {
    background-color : #484848;
    margin: 0;
    padding: 0;
}
h1 {
    color : white;
    text-align : center;
    font-family: "SIMPSON";
}
form {
    width: 300px;
    margin: 0 auto;
    color: black;
    font-size: 20px;
    text-align:center;
}
    </style>

</head>
<body background='http://localhost/onlineShopping/requiredphotos/dbg.jpg'>
    <h1>Update data</h1>
    <form  action="otherupdate.php" method="post">
        Id to update: <input type="varchar(11)" name="Product_id"  required><br><br>
        New Name: <input type="text" name="Product_name" required><br><br>
        New Price: <input type="varchar(20)" name="Product_price" required><br><br>
        New Type: <input type="text" name="Product_type" required><br><br>
        New Size: <input type="varchar(255)" name="Product_size" required><br><br>
        

        <div align="center">
        <input type="submit" name="update" value="Update data">
    </div>
    </form>
<br>

</body>
</html>