<?php
$product_name = filter_input(INPUT_POST, 'product_name');
$product_price = filter_input(INPUT_POST, 'product_price');
$product_type = filter_input(INPUT_POST, 'product_type');
$product_size = filter_input(INPUT_POST, 'product_size');
$allowed_types = ['others','plastic','stationary','food'];

if (!empty($product_name) && !empty($product_price) && !empty($product_type) && !empty($product_size) && isset($_FILES['image'])) {
    $imageName = $_FILES['image']['name'];
    $tempName = $_FILES['image']['tmp_name'];
    $folder = "uploads/" . basename($imageName);
    if (!in_array(strtolower($product_type), $allowed_types)) {
        echo "Type not matched";
        exit;  // stop execution here
    }

    $imageName = $_FILES['image']['name'];
    $tempName = $_FILES['image']['tmp_name'];
    $folder = "uploads/" . basename($imageName);

    if (move_uploaded_file($tempName, $folder)) {
        $host = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "shoping";

        $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

        if ($conn->connect_error) {
            die('Connect Error (' . $conn->connect_errno . ') ' . $conn->connect_error);
        } else {
            $sql = "INSERT INTO fashion (product_name, product_price, product_type,product_size , image)
                    VALUES ('$product_name', '$product_price', '$product_type', '$product_size', '$folder')";

            if ($conn->query($sql)) {
                echo "New record inserted successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            $conn->close();
        }
    } else {
        echo "Image upload failed.";
    }
} else {
    echo "All fields are required.";
}
?>
