<?php
$customer_name = filter_input(INPUT_POST, 'customer_name');
$email = filter_input(INPUT_POST, 'email');
$dob = filter_input(INPUT_POST, 'dob');
$phone_no= filter_input(INPUT_POST, var_name: 'phone_no');
$city = filter_input(INPUT_POST, 'city');
if (!empty($customer_name)){
if (!empty($email)){
if (!empty($dob)){
if (!empty($phone_no)){	
if (!empty($city)){	
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shoping";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO customer (customer_name,email,dob,phone_no,city)
values ('$customer_name','$email','$dob','$phone_no','$city')";
if ($conn->query($sql)){
echo "New record is successfully inserted";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Customer_name should not be empty";
die();
}
}
else{
echo "Customer_email should not be empty";
die();
}
}
else{
	echo "dob should not be empty";
	die();
}
}
else{
	echo "Customer_phone_no should not be empty";
	die();
}
}
else{
	echo "City should not be empty";
	die();
}
?>