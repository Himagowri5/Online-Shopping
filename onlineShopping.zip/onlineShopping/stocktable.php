<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
table {
font-family: "Lato","cursive"; 
width: 100%  }       /* added custom font-family  */

table.one {                                  
margin-bottom: 3em; 
border-collapse:collapse;   }   
 
td {                            /* removed the border from the table data rows  */
text-align: center;     
width: 10em;                    
padding: 1em;       }       
 
th {                              /* removed the border from the table heading row  */
text-align: center;                 
padding: 1em;
background-color: black;       /* added a red background color to the heading cells  */
color: white;       }                 /* added a white font color to the heading text */
 
tr {    
height: 1em;    }
 
table tr:nth-child(even) {            /* added all even rows a #eee color  */
    background-color: #eee;     }
 
table tr:nth-child(odd) {            /* added all odd rows a #fff color  */
background-color:#fff;      }
 
</style>
</head>
<body>
<table>
<tr>
<th>Product_id</th>
<th>Stock_type</th>
<th>Product_name</th>
<th>Stock_qty</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "shoping");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Product_id,Stock_type,Product_name,Stock_qty FROM stocktable";
$result = $conn->query($sql);
if ($result->num_rows>0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Product_id"] . "</td><td>" . $row["Stock_type"] . "</td><td>"
. $row["Product_name"] . "</td><td>" . $row["Stock_qty"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
</body>
</html>