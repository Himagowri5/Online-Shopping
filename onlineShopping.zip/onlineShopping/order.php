<?php
// order.php - Updated to include cart items in the order
$customer_name = filter_input(INPUT_POST, 'customer_name');
$city = filter_input(INPUT_POST, 'city');
$addres = filter_input(INPUT_POST, 'addres');
$pincode = filter_input(INPUT_POST, 'pincode');
$phone_no = filter_input(INPUT_POST, 'phone_no');

if (!empty($customer_name) && !empty($city) && !empty($addres) && !empty($pincode) && !empty($phone_no)) {
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "shoping";

    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert order info into orders table
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, city, addres, pincode, phone_no) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $customer_name, $city, $addres, $pincode, $phone_no);

    if ($stmt->execute()) {
        $order_id = $conn->insert_id; // Get the ID of the inserted order

        // Get items from cart
        $result = $conn->query("SELECT * FROM cart");

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Save each product as an entry in a new table: order_items
                $pname = $row['product_name'];
                $price = $row['product_price'];
                $type = $row['product_type'];
                $size = $row['product_size'];
                $image = $row['image'];

                $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_name, product_price, product_type, product_size, image) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt_item->bind_param("isdsss", $order_id, $pname, $price, $type, $size, $image);
                $stmt_item->execute();
            }

            // Clear the cart after placing the order
            $conn->query("DELETE FROM cart");

            echo "<h2 style='text-align:center;'>Order placed successfully!</h2>";
            echo "<p style='text-align:center;'><a href='index.html'>Back to Shopping</a></p>";
        } else {
            echo "<h3>No products in cart.</h3>";
        }
    } else {
        echo "<h3>Error: Could not place order.</h3>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "<h3>Please fill all required fields.</h3>";
}
?>
