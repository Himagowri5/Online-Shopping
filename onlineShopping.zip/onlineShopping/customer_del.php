<?php
$host         = "localhost";
$username     = "root";
$password     = "";
$dbname       = "furniture";
$result = 0;
/*Create connection */
$conn = new mysqli($host, $username, $password, $dbname);
/*Check connection */
if ($conn->connect_error) {
     die("Connection to database failed: " . $conn->connect_error);
} 
$Customer_name  = intval($_GET['Customer_name']);
if($id){
  $sql    = " delete from customer where Customer_name = ?";
  $stmt   = $conn->prepare($sql);
  $stmt->bind_param('s', $Customer_name);
  $stmt->execute();
  header("Location: records.php");
  exit;
}