<?php

if(isset($_POST['update']))
{
	$host = "localhost";
	$dbusername = "root";
	$dbpassword = "";
    $dbname = "shoping";
    $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

    $stock_type = $_POST['stock_type'];
    $product_name = $_POST['product_name'];
    $stock_qty = $_POST['stock_qty'];

    $sql = "UPDATE stock_table SET stock_type= '$stock_type' ,product_name= '$product_name' ,stock_qty = '$stock_qty' WHERE product_id= '".$product_id."' ";

    if($conn->query($sql))
    {
    	echo "<p><font color=white>Data updated</font></p>";

    }
    else{
    	echo 'Data not updated';
    }
    $conn->close();

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>update data</title>
    <style>
       body {
    background-color : #484848;
    margin: 0;
    padding: 0;
}
h1 {
    color : white;
    text-align : center;
    font-family: "SIMPSON";
}
form {
    width: 300px;
    margin: 0 auto;
    color: orange;
    font-size: 30px;
     text-align:center;
}
    </style>

</head>
<body background='http://localhost/onlineShopping/requiredphotos/vege4.jpg'>
    <h1>Update data</h1>
	<form  action="stupdate.php" method="post">
		Id to update: <input type="int" name="product_id"  required><br><br>
		New stock_type: <input type="varchar(100)" name="stock_type" required><br><br>
		New product_name: <input type="varchar(100)" name="product_name" required><br><br>
		New stock_qty: <input type="int" name="stock_qty" required><br><br>
        <div align="center">
		<input type="submit" name="update" value="Update data">
    </div>
	</form>
    <br>
<div align="center">
    <button onclick="window.location.href = 'http://localhost/onlineShopping/stdelete.php';">Delete</button>
</div>
</body>
</html>