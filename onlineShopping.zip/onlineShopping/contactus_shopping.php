<?php
$First_Name = filter_input(INPUT_POST, 'First_Name');
$Last_Name= filter_input(INPUT_POST, 'Last_Name');
$City= filter_input(INPUT_POST, 'City');
$Comment= filter_input(INPUT_POST, 'Comment');
$Email= filter_input(INPUT_POST,'Email');
if (!empty($First_Name)){
if (!empty($Last_Name)){
if (!empty($City)){
if (!empty($Comment)){
if (!empty($Email)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shoping";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO feedback_table (first_name,last_name,city,comment,email)
values ('$First_Name','$Last_Name','$City','$Comment','$Email')";
if ($conn->query($sql)){
	echo "<body background='http://localhost/onlineShopping/requiredphotos/l-intro-1743011310.jpg'>
            <h1 style='font-style: cursive; font-size: 60px; left:800px ;position: relative; color: red;top: 250px; text-shadow: 
                2px 2px 0px black, 
                -2px -2px 0px black,
                2px -2px 0px black, 
                -2px 2px 0px black;'>Thank You, Visit Again!</h1>
          </body>";}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "First_Name should not be empty";
die();
}
}
else{
echo "Last_Name should not be empty";
die();
}
}
else{
echo "City should not be empty";
die();
}
}
else{
echo "Comment should not be empty";
die();
}
}
else{
	echo "email should not be empty";
	die();
}

?>