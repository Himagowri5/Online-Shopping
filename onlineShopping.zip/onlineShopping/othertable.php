<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shoping";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch only 'laptop' and 'phone'
$sql = "SELECT * FROM fashion WHERE product_type = 'others' OR product_type = 'plastic'OR product_type = 'food'OR product_type = 'stationary'";
$result = $conn->query($sql);

// CSS styling
echo "
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        color: black;
        text-align: center;
        font-family: Arial, sans-serif;
    }
    th {
        background-color: rgb(21, 48, 79);
        color: white;
        padding: 10px;
    }
    td {
        background-color: #E3F2FD;
        padding: 8px;
        border: 1px solid #ccc;
    }
    tr:nth-child(even) td {
        background-color: #F0F7FF;
    }
    .cart-button {
        padding: 6px 12px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .cart-button:hover {
        background-color: #218838;
    }
</style>
";

// Start table
echo "<table border='1'>";
echo "<tr>
        <th>Name</th>
        <th>Price</th>
        <th>Type</th>
        <th>Quantity</th>
        <th>Image</th>
        <th>Add to Cart</th>
      </tr>";

// Loop through products
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["product_name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["product_price"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["product_type"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["product_size"]) . "</td>";
        echo "<td><img src='" . htmlspecialchars($row["image"]) . "' width='100' height='100'></td>";
        
        // Updated: send product_name instead of product_id
        echo "<td>
                <form method='post' action='cart.php'>
                    <input type='hidden' name='product_name' value='" . htmlspecialchars($row["product_name"]) . "'>
                    <input type='submit' class='cart-button' value='Add to Cart'>
                </form>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No records found</td></tr>";
}

echo "</table>";

$conn->close();
?>
