<?php

if(isset($_POST['delete']))
{
	$host = "localhost";
	$dbusername = "root";
	$dbpassword = "";
    $dbname = "shoping";
    $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

    $Product_id = $_POST['product_id'];

    $sql = "DELETE FROM stock_table WHERE product_id= '".$product_id."' ";

    if($conn->query($sql))
    {
    	echo "<p><font color=white>Data deleted</font></p>";

    }
    else{
    	echo 'Data not deleted';
    }
    $conn->close();

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>delete data</title>
    <style>
       body {
    background-color : #484848;
    margin: 0;
    padding: 0;
}
h1 {
    color : white;
    text-align : center;
    font-family: "SIMPSON";
}
form {
    width: 300px;
    margin: 0 auto;
    color: orange;
    font-size: 30px;
}
    </style>

</head>
<body >
    <h1>Delete data</h1>
	<form  action="stdelete.php" method="post">
		Id to delete: <input type="int" name="product_id"  required><br><br>
		<input type="submit" name="delete" value="Delete data">
	</form>
</body>
</html>